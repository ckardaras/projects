#include "dots.h"

dots::dots()
{

}
