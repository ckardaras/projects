#include <iostream>
#include <string>
#include <map>
#include "Counter.h"
#include "TestTypes.h"

using namespace std;





int main()
{
  //Tests for templates uncommented, commented out is tests for struct and enum Color


    /*Player p1{"jon",10.0};
    Player p2{"Mary",17.0};
    Player p3{"Tony",100.0};
    cout<<p3.name<<endl;
    Counter<Player> Test;*/
    /*Test.Insert(p1, 14);
    Test.Insert(p2, 40);
    Test.Insert(p3, 17);
    Test.iterate();*/
    Counter<string> Test;
    /*Counter<Color> Test;
    Test.Insert(Color::green, 14);
    Test.Insert(Color::red, 9);
    Test.Insert(Color::blue, 4);*/
    Test.Insert("Ted", 2);
    Test.Insert("Joe", 5);
    Test.Insert("Marvel", 1);
    Test.Insert("Bob", 4);
    Test.Insert("Andrew", 6);
    Test.Insert("Chris", 2);
    Test.MostCommon(10);
    cout<<endl;
    Test.LeastCommon(10);
    cout<<Test<<endl;

    Test.Remove("Andrew");

    cout<<Test<<endl;

    Test.Range(2,5);

    Test.normalizeWeights();
    //Test.Insert(Color::red,10);
    Test.iterate();
    /*cout<<Test.Total()<<endl;
    cout<<Test.GetValue("Andrew")<<endl;*/
    Test.incrementOne("Chris");
    Test.iterate();
    Test.incrementByN("Joe",30);
    Test.decrementByN("Marvel",5);
    Test.iterate();
    Test.decrementOne("Bob");
    Test.iterate();

}
