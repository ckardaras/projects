#ifndef COUNTER_H
#define COUNTER_H

#include <map>
#include <vector>
#include <iostream>
#include "TestTypes.h"
#include <string>
#include <sstream>

using namespace std;

template <typename T>
class Counter
{

    public:
        //main map
        map<T,int> myMap;

        //iteration map
        typename map<T,int>::iterator itr;

        //make empty counter of type T
        Counter()
        {
        } //Constructor

        virtual ~Counter() = default;

        void iterate()
        {
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
                cout<<itr->first;
                cout<<" : ";
                cout<<itr->second;
                cout<<endl;
            }
        }

        //insert a pair of T and int into myMap field
        void Insert(const T key, int value)
        {
            myMap.insert(pair<T ,int>(key, value));
        }


        //get total
        int Total()
        {
            int total=0;
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
                total=total+itr->second;
            }
            return total;
        }


        //get values of a particular key
        int GetValue(const T key)
        {
            if(myMap.find(key)==myMap.end())
            {
                return 0;
            }
            else
            {
                return myMap.at(key);
            }
        }

        //Following 4 functions increment and decrement according to their names
        void incrementOne(const T key)
        {
            int value = GetValue(key);
            value++;
            myMap.at(key)=value;
        }

        void incrementByN(const T key, int N)
        {
            int value = GetValue(key);
            value= value+N;
            myMap.at(key)=value;
        }

        void decrementOne(const T key)
        {
            int value = GetValue(key);
            value--;
            myMap.at(key)=value;
        }

        void decrementByN(const T key, int N)
        {
            int value = GetValue(key);
            value= value-N;
            myMap.at(key)=value;
        }


        //get vector of all kets
        vector<T> getAllKeys()
        {
            vector<T> listOfKeys;
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
               listOfKeys.push_back(itr->first);
            }
            return listOfKeys;
        }

        //get vector of all values
        vector<int> getAllValues()
        {
            vector<T> listOfvals;
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
               listOfvals.push_back(itr->second);
            }
            return listOfvals;

        }

        //get a singular key returned as a string
        string getKey(const T n)
        {
            ostringstream stm;
            stm<<n;
            return stm.str();
        }


        //return map of n most common
        map<T,int> MostCommon(uint n)
        {
            vector<T> listOfKeys;
            T temp;
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
               listOfKeys.push_back(itr->first);
            }
            for (uint x=0; x<listOfKeys.size()-1; x++)
            {
                if(GetValue(listOfKeys[x])<GetValue(listOfKeys[x+1]))
                {
                    temp = listOfKeys[x];
                    listOfKeys[x]=listOfKeys[x+1];
                    listOfKeys[x+1]=temp;
                    x=-1;
                }
            }
            if(n>listOfKeys.size())
            {
                n=listOfKeys.size();
            }
            map<T,int> result;
            for (uint i=0; i<n; i++)
            {
                cout<<getKey(listOfKeys[i])<<" : "<<GetValue(listOfKeys[i])<<endl;
                result.insert({listOfKeys[i],GetValue(listOfKeys[i])});
            }
            return result;
        }


        //return map of n least common
        map<T,int> LeastCommon(uint n)
        {
            vector<T> listOfKeys;
            T temp;
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
               listOfKeys.push_back(itr->first);
            }
            for (uint x=0; x<listOfKeys.size()-1; x++)
            {
                if(GetValue(listOfKeys[x+1])<GetValue(listOfKeys[x]))
                {
                    temp = listOfKeys[x];
                    listOfKeys[x]=listOfKeys[x+1];
                    listOfKeys[x+1]=temp;
                    x=-1;
                }
            }
            if(n>listOfKeys.size())
            {
                n=listOfKeys.size();
            }
            map<T,int> result;
            for (uint i=0; i<n; i++)
            {
                cout<<getKey(listOfKeys[i])<<" : "<<GetValue(listOfKeys[i])<<endl;
                result.insert({listOfKeys[i],GetValue(listOfKeys[i])});
            }
            return result;
        }

        //return normalized map
        map<T, double> normalizeWeights()
        {
            map<T,double> normalizedMap;
            for(const auto &p: myMap)
            {
                double converter = p.second;
                normalizedMap.insert(pair<T ,double>(p.first, converter/Total()));
            }
            for(const auto &p: normalizedMap)
            {
                cout<<p.first<<" : ";
                cout<<p.second<<endl;
            }
            return normalizedMap;
        }

        //remove obj T from map
        void Remove(T key)
        {
            itr=myMap.find(key);
            myMap.erase(itr);
        }

        //get keys with values in range
        int Range(const int minimum, const int maximum)
        {
            int total=0;
            vector<T> listOfKeys;
            T temp;
            for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
            {
               listOfKeys.push_back(itr->first);
            }
            for (uint x=0; x<listOfKeys.size()-1; x++)
            {
                if(GetValue(listOfKeys[x+1])<GetValue(listOfKeys[x]))
                {
                    temp = listOfKeys[x];
                    listOfKeys[x]=listOfKeys[x+1];
                    listOfKeys[x+1]=temp;
                    x=-1;
                }
            }
            //map<T,int> result;
            for (uint i=0; i<listOfKeys.size(); i++)
            {
                if(((GetValue(listOfKeys[i]))>=minimum)&&(GetValue(listOfKeys[i])<=maximum))
                {
                    cout<<getKey(listOfKeys[i])<<" : "<<GetValue(listOfKeys[i])<<endl;
                    total+=(GetValue(listOfKeys[i]));
                }
            }
            return total;
        }

        //overload = operator -- access a converted counter as a regular c++ map
        T & operator = (const map<T,int> someMap)
        {
            myMap = someMap;
        }

        //allows setting values of already existing keys
        void setValue(T key, int value)
        {
            itr=myMap.find(key);
            if(itr!=myMap.end())
            {
                itr->second=value;
            }
        }


        //overload << operator
        friend std::ostream& operator<< (std::ostream &os, const Counter<T> &ct)
        {
            for(const auto &p: ct.myMap)
            {
                os << p.first <<" : ";
                os << p.second<<endl;
            }
            return os;
        }
        //read in vector
        void initialize(vector<T> keys)
        {
            for (uint i=0; i<keys.size(); i++)
            {
                myMap[keys[i]];
            }
        }

        /*friend std::ostream& operator<< (std::ostream &os, const Counter<Color> &ct)
        {
            for(const auto &p: ct.myMap)
            {
                os << p.first <<" : ";
                os << p.second<<endl;
            }
            return os;
        }*/



};

//Specific custom enum/struct/class functions

template<>
void Counter<Color>::iterate()
{
    for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
    {
        if(itr->first==Color::red)
        {
            cout<<"red";
        }
        else if(itr->first==Color::green)
        {
            cout<<"green";
        }
        else if(itr->first==Color::blue)
        {
            cout<<"blue";
        }
            cout<<" : ";
            cout<<itr->second;
            cout<<endl;
        }
}

template<>
string Counter<Color>::getKey(Color key)
{
    if(key==Color::red)
    {
        return "red";
    }
    else if(key==Color::green)
    {
        return "green";
    }
    else
    {
        return "blue";
    }
}

template<>
void Counter<Player>::iterate()
{
    for (itr=myMap.begin(); itr!=myMap.end(); ++itr)
    {
        {
            cout<<itr->first.name <<" : ";
            cout<<itr->second<<endl;
        }
    }
}

template<>
string Counter<Player>::getKey(Player key)
{
    return key.name;
}





#endif // COUNTER_H
