#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "catch.hpp"
#include <iostream>
#include <vector>
#include "Counter.h"

//Name: Chris Kardaras
using namespace std;
//Side Note: Many of the functions that return void were tested in main


TEST_CASE ( "String Test", "[Counter]")
{
  Counter<string> Test;
  Test.Insert("Abc",5);
  vector<string> v={"Bcd","Cde"};
  Test.initialize(v);
  Test.setValue("Bcd", 3);
  Test.setValue("Cde",2);
  cout<<Test;
  cout<<endl;
  REQUIRE(Test.GetValue("Cde")==2);
  REQUIRE(Test.Total()==10);
  REQUIRE(Test.Range(3,5)==8);
  map<string,int> holder1=Test.MostCommon(1);
  REQUIRE(holder1["Abc"]==5);
  map<string,int> holder2=Test.LeastCommon(1);
  REQUIRE(holder2["Cde"]==2);
  Test.Remove("Bcd");
  REQUIRE(Test.myMap.size()==2);
  Test.normalizeWeights();
}

TEST_CASE ( "Int", "[Counter]")
{
  Counter<int> Test;
  Test.Insert(1,5);
  vector<int> v={2,3};
  Test.initialize(v);
  Test.setValue(2, 3);
  Test.setValue(3,2);
  cout<<Test;
  cout<<endl;
  REQUIRE(Test.GetValue(3)==2);
  REQUIRE(Test.Total()==10);
  REQUIRE(Test.Range(3,5)==8);
  map<int,int> holder1=Test.MostCommon(1);
  REQUIRE(holder1[1]==5);
  map<int,int> holder2=Test.LeastCommon(1);
  REQUIRE(holder2[3]==2);
  Test.Remove(2);
  REQUIRE(Test.myMap.size()==2);
  Test.normalizeWeights();
}

/*TEST_CASE ( "Enum", "[Counter]")
{
  Counter<Color> Test;
  Test.Insert(Color::red,5);
  vector<int> v={Color::blue,Color::green};
  Test.initialize(v);
  Test.setValue(Color::blue, 3);
  Test.setValue(Color::green,2);
  cout<<Test;
  cout<<endl;
  REQUIRE(Test.GetValue(Color::green)==2);
  REQUIRE(Test.Total()==10);
  REQUIRE(Test.Range(3,5)==8);
  map<Color,int> holder1=Test.MostCommon(1);
  REQUIRE(holder1[1]==5);
  map<Color,int> holder2=Test.LeastCommon(1);
  REQUIRE(holder2[3]==2);
  Test.Remove(2);
  REQUIRE(Test.myMap.size()==2);
  Test.normalizeWeights();
}*/
