#ifndef ELECTION_H
#define ELECTION_H

#include "ElectoralMap.h"
#include <iostream>

using namespace std;



class Election
{
    public:
      Election(map<int, candidate> CandidateList); //constructor
      virtual ~Election();
      virtual void tally(); //vote method
      Party Most(District); //Find most popular party in a district
      Party MostExclude(District, Party); //Find most popular party in a district not including given party
      vector<int> CandidatesinParty(Party j); //returns vector of candidates in given party
      void showResults(); //prints out how people voted, and who the winner is
      string campaign();  //manages campaign action
      string CampaignSetup(); //campaign setup
      int listCandidates(string input); //lists candidates
      int CampaignLocation(); //gets district key for campaign
      double PSuc(candidate pol, District A, double r); //the P_Success method, used in campaign()
      bool PExtraSuc(double r, double equation); //the P_Extra_Success method, does comparison returns true of false
      void printDistricts(); //print status of districts
      ElectoralMap &EMapRef = ElectoralMap::getInstance(); // both the amp and EMap variables were initally private, but it messed with inheritance
      map<int, candidate> AllCandidates;
};

class repElection : public Election
{
  //void tally();

};

class tyranny : public Election
{
  //void tally();
};

#endif // ELECTION_H
