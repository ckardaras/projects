#include <iostream>
#include <string>
#include "TextUI.h"

using namespace std;


//Code below was found online
//(https://stackoverflow.com/questions/261963/how-can-i-iterate-over-an-enum)
//to allow to iterate through enum classes
//*****************************************
template < typename C, C beginVal, C endVal>
class Iterator {
  typedef typename std::underlying_type<C>::type val_t;
  int val;
public:
  Iterator(const C & f) : val(static_cast<val_t>(f)) {}
  Iterator() : val(static_cast<val_t>(beginVal)) {}
  Iterator operator++() {
    ++val;
    return *this;
  }
  C operator*() { return static_cast<C>(val); }
  Iterator begin() { return *this; } //default ctor is good
  Iterator end() {
      static const Iterator endIter=++Iterator(endVal); // cache it
      return endIter;
  }
  bool operator!=(const Iterator& i) { return val != i.val; }
};

//*****************************************
//Add a value to enum and modify what the Party end value is
typedef Iterator<Party, Party::None, Party::Three> PartyIterator;

TextUI::TextUI()
{
}

TextUI::~TextUI()
{
    //dtor
}

void TextUI::DisplayDists()
{
  for (int i=1; i<=Em.getAssignDistID();i++)
  {
    cout<<"District "<<i<<endl;
    for(Party j: PartyIterator())
    {
      cout<<Em.getPartyString(j)<<": "<<Em.AllDistricts[i].Cons[j]<<endl;
    }
    cout<<endl;

  }
}

void TextUI::AddCandidate()
{
  string input, name;
  int answer;
  Party affiliation;
  map <int, Party> mapEnum;
  int enumSize;
  start:
  cout<<"Do you want to add a new candidate?"<<endl;
  cout<<"enter y for yes, n for no"<<endl;
  do{
    cin>>input;
    if(input!="y" && input!="n")
    {
      cout<<"Enter a valid input!"<<endl;
    }
  } while(input!="y" && input!="n");
  if(input=="n" && CandidateList.size()==0)
  {
    input="y";
    cout<<"Must have at least one candidate running"<<endl;
  }
  if (input=="y")
  {
    cout<<"what is the candidate's name?"<<endl;
    cin>>name;
    cout<<"what party number does the candidate belong to?"<<endl;
    enumSize=0;
    for(Party j: PartyIterator())
    {
      mapEnum.insert({enumSize,j});
      enumSize++;
    }
    do{
      cin>>answer;
      if (answer>enumSize||answer<=0)
      {
        cout<<"Choose a valid number!"<<endl;
      }
      else
      {
        affiliation=mapEnum[answer];
      }
    }while(answer>enumSize || answer<=0);
    candidate NewCandidate{CID, name,affiliation,0};
    CandidateList.insert(std::pair<int,candidate>(CID,NewCandidate));
    CID++;
    input="";
    goto start;
  }
}

void TextUI::startElection()
{
  new Election(CandidateList);
}


void TextUI::startrepElection()
{
  //new repElection(CandidateList);
  new Election(CandidateList);
}

void TextUI::startTyranny()
{
  //new tyranny(CandidateList);
  new Election(CandidateList);
}
