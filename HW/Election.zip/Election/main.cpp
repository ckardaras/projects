#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ElectoralMap.h"
#include "TextUI.h"


//Chris Kardaras

using namespace std;

int main()
{
    srand (time(NULL));
    int textinput;
    TextUI myText;
    string goAgain;
    do
    {
      myText.DisplayDists();
      cout<<"What type of election do you want: 1 for Normal, 2 for Representative, 3 for Dictatorship"<<endl;
      do
      {
        cin>>textinput;
      }while(textinput<1||textinput>3);
      myText.AddCandidate();
      if(textinput==1)
      {
        myText.startElection();
      }
      else if(textinput==2)
      {
          myText.startrepElection(); //could not get overriden functions to be called
      }
      else if(textinput==3)
      {
          myText.startTyranny();
      }
      myText.clean();
      cout<<"Go again? Enter 'y' for yes, any other input for no"<<endl;
      cin>>goAgain;
    }while(goAgain=="y");
}
