#ifndef ELECTORALMAP_H
#define ELECTORALMAP_H

#include <map>
#include <vector>
#include <string>

using namespace std;


enum class Party
{
  None,
  One,
  Two,
  Three
};


struct candidate
{
  int id_;
  string name_;
  Party affiliation_;
  int voteCount_;
};

class District
{
  public:
    District();
    ~District();
    map<Party,int> Cons;
    int getSize()
    {
      return Size;
    }
  private:
    int DistID;
    int Size;
    int ConCount;


};


class ElectoralMap
{
    public:
      static map<int, District> AllDistricts; //map of districts

      static ElectoralMap& getInstance()
      {
        static ElectoralMap instance;

        return instance;
      }

      string getPartyString(Party value); //takes a party and returns a string of party name

      static int getAssignDistID() //gets private AssignDistID attribute
      {
        return AssignDistID;
      }

    private:
      ElectoralMap();
      static const int NumDistricts = 2;
      static int AssignDistID;
      void DistrictGenerator();



};

#endif // ELECTORALMAP_H
