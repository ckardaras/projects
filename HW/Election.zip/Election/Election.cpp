#include "Election.h"
#include <vector>
#include <iostream>
#include <math.h>

using namespace std;

//Code below was found online
//(https://stackoverflow.com/questions/261963/how-can-i-iterate-over-an-enum)
//to allow to iterate through enum classes
//*****************************************
template < typename C, C beginVal, C endVal>
class Iterator {
  typedef typename std::underlying_type<C>::type val_t;
  int val;
public:
  Iterator(const C & f) : val(static_cast<val_t>(f)) {}
  Iterator() : val(static_cast<val_t>(beginVal)) {}
  Iterator operator++() {
    ++val;
    return *this;
  }
  C operator*() { return static_cast<C>(val); }
  Iterator begin() { return *this; } //default ctor is good
  Iterator end() {
      static const Iterator endIter=++Iterator(endVal); // cache it
      return endIter;
  }
  bool operator!=(const Iterator& i) { return val != i.val; }
};

//*****************************************
//Add a value to enum and modify what the Party end value is
typedef Iterator<Party, Party::None, Party::Three> PartyIterator;

Election::Election(map<int, candidate> CandidateList)
{
  string input="";
  AllCandidates=CandidateList;
  do
  {
    input=campaign();
  }while(input=="y");
  tally();
  showResults();

}

Election::~Election()
{
    //dtor
}

string Election:: CampaignSetup()
{
    string input;
    cout<<"Do you want to campaign with any candidates?"<<endl;
    cout<<"Enter 'y' for yes, 'n' for no"<<endl;
    do{
      cin>>input;
      if(input!="y"&&input!="n")
      {
        cout<<"Enter a valid command!"<<endl;
      }
    }while(input!="y"&&input!="n");
    return input;
}

int Election::listCandidates(string input)
{
  int selection=-1;
  if(input=="y")
  {
      cout<<"Choose a candidate"<<endl;
      for(uint i=0;i<AllCandidates.size();i++)
      {
        cout<<i<<": ";
        cout<<AllCandidates[i].name_;
        cout<<" ["<<EMapRef.getPartyString(AllCandidates[i].affiliation_)<<"]"<<endl;
      }
      do
      {
        cin>>selection;
        if(selection<0 || selection>=AllCandidates.size())
        {
          cout<<"Choose a valid option"<<endl;
        }
      }while(selection<0 || selection>=AllCandidates.size());
  }
  return selection;
}

int Election::CampaignLocation()
{
  int where;
  for (int i=1; i<=EMapRef.getAssignDistID();i++)
  {
    cout<<"District "<<i<<endl;
    cout<<"Square Miles: "<<EMapRef.AllDistricts[i].getSize()<<endl;
    for(Party j: PartyIterator())
    {
      cout<<EMapRef.getPartyString(j)<<": "<<EMapRef.AllDistricts[i].Cons[j]<<endl;
    }
    cout<<endl;
  }
  cout<<"Where is this candidate campaigning?"<<endl;
  do
  {
    cin>>where;
    if(where<0 || where>EMapRef.getAssignDistID())
    {
      cout<<"Enter a valid number"<<endl;
    }
  }while(where<0 || where>EMapRef.getAssignDistID());
  return where;
}

string Election::campaign()
{
  //ask if want to campaign
  string input;
  int selection;
  int where;
  input=CampaignSetup();
  if(input=="y")
  {
    //list out CandidatesinParty and get selection
    selection=listCandidates(input);
    //list out locations and get selection
    where=CampaignLocation();
    cout<<AllCandidates[selection].name_<<" is campaigning in district "<<where<<endl;
    double r = (double)rand()/(double)RAND_MAX;

    double result = PSuc(AllCandidates[selection],EMapRef.AllDistricts[where],r);
    //cout<<"Random: "<<r<<endl;
    //cout<<"Result: "<<result<<endl;
    //option 4, no changes
    if(result!=0)
    {
    //option1->1 None to party of candidate
      //PSuc is successfull
      if(EMapRef.AllDistricts[where].Cons[Party::None]!=0)
      {
        EMapRef.AllDistricts[where].Cons[Party::None]--;
        EMapRef.AllDistricts[where].Cons[AllCandidates[selection].affiliation_]++;

        //PExtraSuc is successfull
        //option2->2 None, 1 to candidate, 1 to majority (that is not candidate)
        if((PExtraSuc(r,result)==true))
        {
          Party MostPopular = MostExclude(EMapRef.AllDistricts[where],AllCandidates[selection].affiliation_);
          if(EMapRef.AllDistricts[where].Cons[MostPopular]!=0)
          {
            EMapRef.AllDistricts[where].Cons[MostPopular]--;
            EMapRef.AllDistricts[where].Cons[AllCandidates[selection].affiliation_]++;
          }
        }
        //option3->1 from Majority that is not candidate to CandidateList
      }
    }
    else if((PExtraSuc(r,result)==true)&&(EMapRef.AllDistricts[where].Cons[Party::None]==0))
    {
      Party MostPopular = MostExclude(EMapRef.AllDistricts[where],AllCandidates[selection].affiliation_);
      if(EMapRef.AllDistricts[where].Cons[MostPopular]!=0)
      {
        EMapRef.AllDistricts[where].Cons[MostPopular]--;
        EMapRef.AllDistricts[where].Cons[AllCandidates[selection].affiliation_]++;
      }
    }
    printDistricts();
    cout<<"Go again? 'y' for yes, any other value for no"<<endl;
    cin>>input;
  }
  return input;
}

double Election::PSuc(candidate pol, District A, double r)
{
  Party affiliation=pol.affiliation_;
  double equation=0;
  double inParty=((A.Cons[affiliation])+1)*2;
  double inotherParties=0;
  for(Party j: PartyIterator())
  {
    if(j!=affiliation||j!=Party::None)
    {
      inotherParties+=A.Cons[j];
    }
  }
  double leftSide=inParty/inotherParties;
  double rightSide=inParty/(A.getSize());
  equation = leftSide*rightSide;
  if(equation > r)
  {
    return equation;
  }
  else
  {
    return 0;
  }
}

void Election::printDistricts()
{
  for (int i=1; i<=EMapRef.getAssignDistID();i++)
  {
    cout<<"District "<<i<<endl;
    cout<<"Square Miles: "<<EMapRef.AllDistricts[i].getSize()<<endl;
    for(Party j: PartyIterator())
    {
      cout<<EMapRef.getPartyString(j)<<": "<<EMapRef.AllDistricts[i].Cons[j]<<endl;
    }
    cout<<endl;
  }
}




bool Election:: PExtraSuc(double r, double equation)
{
  if((equation*0.1)>r)
  {
    return true;
  }
  else{
    return false;
  }
}


Party Election::Most(District A)
{
  Party BiggestParty;
  int BiggestCount=-1;
  for(Party j: PartyIterator())
  {
    if(A.Cons[j]>BiggestCount && j!=Party::None)
    {
        BiggestParty=j;
        BiggestCount=A.Cons[j];
    }
  }
  return BiggestParty;
}

Party Election::MostExclude(District A,Party B)
{
  Party BiggestParty;
  int BiggestCount=-1;
  for(Party j: PartyIterator())
  {
    if(A.Cons[j]>BiggestCount && j!=Party::None && j!=B)
    {
        BiggestParty=j;
        BiggestCount=A.Cons[j];
    }
  }
  return BiggestParty;
}

vector<int> Election::CandidatesinParty(Party j)
{
  vector<int> result;
  for (uint i=0;i<AllCandidates.size();i++)
  {
      if(AllCandidates[i].affiliation_==j)
      {
        result.push_back(i);
      }
  }
  return result;
}

void Election::tally()
{
  int value=0;
  Party BiggestParty;
  vector<int> CanKeys;
  for(int i=1; i<=EMapRef.getAssignDistID(); i++)
  {
    BiggestParty=Most(EMapRef.AllDistricts[i]);
    for(Party j: PartyIterator())
    {
      if(j==Party::None)
      {
        value=EMapRef.AllDistricts[i].Cons[j];
        for(int x=0; x<value; x++)
        {
          int isecret=(rand()%10)+1;
          if(isecret<=7)
          {
            CanKeys=CandidatesinParty(BiggestParty);
            if(CanKeys.size()!=0)
            {
              isecret=rand()%(CanKeys.size());
              AllCandidates[CanKeys[isecret]].voteCount_+=1;
            }
            else
            {
              isecret=rand()%(AllCandidates.size());
              AllCandidates[isecret].voteCount_+=1;
            }
          }
          else
          {
            isecret=rand()%(AllCandidates.size());
            AllCandidates[isecret].voteCount_+=1;
          }
        }
      }
      else
      {
        value=EMapRef.AllDistricts[i].Cons[j];
        int isecret=(rand()%10)+1;
        for(int x=0; x<value; x++)
        {
          CanKeys=CandidatesinParty(j);
          if((CanKeys.size()==0)||(isecret==10))
          {
            isecret=rand()%(AllCandidates.size());
            AllCandidates[isecret].voteCount_+=1;
          }
          else if(isecret<=9)
          {
            isecret=rand()%(CanKeys.size());
            AllCandidates[CanKeys[isecret]].voteCount_+=1;
          }
        }
      }
    }
  }
}


void Election::showResults()
{
  candidate winner;
  int winningtally=-1;
  for(uint i=0; i<AllCandidates.size(); i++)
  {
    cout<<AllCandidates[i].name_<<" ["<<EMapRef.getPartyString(AllCandidates[i].affiliation_)<<"] with "<<AllCandidates[i].voteCount_<<" Votes"<<endl;
    if(AllCandidates[i].voteCount_>winningtally)
    {
      winningtally=AllCandidates[i].voteCount_;
      winner=AllCandidates[i];
    }
  }
  cout<<winner.name_<<" won!"<<endl;
}


/*void repElection::tally()
{
  cout<<"test";//Derived class not calling inherited method
}


void tyranny::tally()
{
  int allCons=0;
  for(int i=1; i<=EMapRef.getAssignDistID(); i++)
  {
    for(Party j: PartyIterator())
    {
      allCons+=EMapRef.AllDistricts[i].Cons[j];
    }
  }
  cout<<allCons;
}*/
