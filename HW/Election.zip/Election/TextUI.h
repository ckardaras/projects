#ifndef TEXTUI_H
#define TEXTUI_H

#include <map>
#include "ElectoralMap.h"
#include "Election.h"

using namespace std;

class TextUI
{
    public:
        TextUI();
        virtual ~TextUI();
        void DisplayDists(); //prints out district values at start of program
        void AddCandidate(); //adds canidates, which are then put into the map in the election class
        void startElection(); //starts the normal election
        void startrepElection();//not functioning properly
        void startTyranny(); //extracredit-not functioning
        void clean(){
          CandidateList.clear();
          CID=0;
        } //resets candidate ids and gets rid of candidates from last election


    private:
      ElectoralMap &Em = ElectoralMap::getInstance();
      map<int,candidate>CandidateList;
      int CID=0;
};

#endif // TEXTUI_H
