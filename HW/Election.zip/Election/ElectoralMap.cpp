#include "ElectoralMap.h"
#include <map>
#include <type_traits>


using namespace std;



//Code below was found online
//(https://stackoverflow.com/questions/261963/how-can-i-iterate-over-an-enum)
//to allow to iterate through enum classes
//*****************************************
template < typename C, C beginVal, C endVal>
class Iterator {
  typedef typename std::underlying_type<C>::type val_t;
  int val;
public:
  Iterator(const C & f) : val(static_cast<val_t>(f)) {}
  Iterator() : val(static_cast<val_t>(beginVal)) {}
  Iterator operator++() {
    ++val;
    return *this;
  }
  C operator*() { return static_cast<C>(val); }
  Iterator begin() { return *this; } //default ctor is good
  Iterator end() {
      static const Iterator endIter=++Iterator(endVal); // cache it
      return endIter;
  }
  bool operator!=(const Iterator& i) { return val != i.val; }
};

//*****************************************
//Add a value to enum and modify what the Party end value is
typedef Iterator<Party, Party::None, Party::Three> PartyIterator;


int ElectoralMap::AssignDistID=0;
map<int,District> ElectoralMap:: AllDistricts;



District::District()
{
  Size=rand()%24+5;
  for(Party i: PartyIterator())
  {
    Cons.insert({i,(rand()%9)});
  }
}

District::~District()
{
    //dtor
}

void ElectoralMap::DistrictGenerator()
{
  for (int i=0; i<NumDistricts; i++)
  {
    AssignDistID++;
    AllDistricts.emplace(AssignDistID,*(new District));
  }

}

ElectoralMap::ElectoralMap()
{
  DistrictGenerator();
}

string ElectoralMap::getPartyString(Party value)
{
  if (value==Party::None)
    return "None";
  else if(value==Party::One)
    return "Party One";
  else if(value==Party::Two)
      return "Party Two";
  else if(value==Party::Three)
      return "Party Three";

    //for any parties just add another else if line
}
