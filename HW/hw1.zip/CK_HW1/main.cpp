#include <iostream>
#include <string>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "Maze.h"
#include "Player.h"

using namespace std;

void setup();

int main()
{

  Player p1("Chris", true);
  Player *p1_ref = &p1;
  Maze myMaze;
  myMaze.NewGame(p1_ref,2);
}
