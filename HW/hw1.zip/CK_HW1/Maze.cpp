#include <string>
#include <iostream>
#include <vector>
#include <locale>
#include "Maze.h"


using namespace std;

//Board constructor sets board tile values as well
Board::Board()
{
    srand(time(NULL));
    for (int x=0; x<get_cols(); x++)
    {
      for (int y=0; y<get_rows(); y++)
      {
        arr_[x][y]=setRandSquare();
      }
    }
    arr_[get_cols()-1][get_rows()-1] = SquareType::Exit;
    arr_[0][0]=SquareType::Human;
}

//Returns a squaretype determined by random number generation
SquareType Board::setRandSquare()
{
  int iSecret = rand() %10 + 1;
  if (iSecret <= 2)
  {
    return SquareType::Wall;
  }
  else if(iSecret == 3)
  {
    return SquareType::Treasure;
  }
  else
  {
    return SquareType::Empty;
  }
}

//draws a visual representation of the current state of the board
void Board::drawBoard()
{
    for (int y=0; y<get_rows(); y++)
    {
        cout<<endl;
        for (int x=0; x<get_cols(); x++)
        {
            if (arr_[x][y]==SquareType::Human)
            {
                cout<<"|__P__|";
            }
            else if (arr_[x][y]==SquareType::Wall)
            {
                cout<<"|XXXXX|";
            }
            else if (arr_[x][y]==SquareType::Treasure)
            {
                cout<<"|_[T]_|";
            }
            else if (arr_[x][y]==SquareType::Enemy)
            {
                cout<<"|('x')|";
            }
            else if (arr_[x][y]==SquareType::Empty)
            {
                cout<<"|_____|";
            }
            else if (arr_[x][y]==SquareType::Exit)
            {
                cout<<"|_EXT_|";
            }
        }
    }
    cout<<endl;
    return;
}

//returns the current value for a particular position on the board
SquareType Board::get_square_value(Position pos) const
{
    int x = pos.col;
    int y = pos.row;
    return (arr_[x][y]);
}

//sets a particular position on the board to a certain value
void Board::SetSquareValue(Position pos, SquareType value)
{
  int x = pos.col;
  int y = pos.row;
  arr_[x][y] = value;
}

//This puts all available moves into a vector
vector<Position> Board::GetMoves(Player *p)
{
  vector<Position> MoveList;
  int y = p->get_position().row;
  int x = p->get_position().col;
  if (y>0) //up
  {
    if (arr_[x][y-1]!=SquareType::Wall)
    {
      Position Up;
      Up.col = x;
      Up.row = y-1;
      MoveList.push_back(Up);
    }
  }
  if(x>0) //left
  {
    if (arr_[x-1][y]!=SquareType::Wall)
    {
      Position Left;
      Left.col = x-1;
      Left.row = y;
      MoveList.push_back(Left);
    }
  }
  if(y<(get_rows()-1)) //down
  {
    if (arr_[x][y+1]!=SquareType::Wall)
    {
      Position Down;
      Down.col = x;
      Down.row = y+1;
      MoveList.push_back(Down);
    }
  }

  if(x<(get_cols()-1)) //right
  {
    if (arr_[x+1][y]!=SquareType::Wall)
    {
      Position Right;
      Right.col = x+1;
      Right.row = y;
      MoveList.push_back(Right);
    }
  }
  return MoveList;
}

//Normalizes player input
string Board::Command()
{
  string command;
    cin>>command;
    int len = command.length();
    for (int i=0; i<len; i++)
    {
      command[i]=toupper(command[i]);
    }
    return command;
}

//Checks if the option the player or bot input is a valid selection
bool Board::MovePlayer(Player *p, Position pos)
{
  vector <Position> AvailableMoves;
  for (uint i=0; i<GetMoves(p).size();i++)
  {
    AvailableMoves.push_back(GetMoves(p)[i]);
  }
  bool legal = false;
  for (uint i=0; i<AvailableMoves.size(); i++)
  {
    if(AvailableMoves[i]==pos)
    {
      legal = true;
    }
  }
  return legal;
}

//Wraps all related player movement function into one easy to declare function
//The function does different things based on the player is_human_ value
void Board::Move(Player *p)
{
  string s;
  bool ValidSpot = false;
  Position newSpot;
  startAgain:
  ValidSpot = false;
  string order;
  Position Up = p->get_position();
  Position Left = p->get_position();
  Position Right = p->get_position();
  Position Down = p->get_position();
  Up.row=Up.row-1;
  Left.col=Left.col-1;
  Right.col=Right.col+1;
  Down.row=Down.row+1;
  vector<Position> AvailableMoves;
  if(p->is_human()==true){
  s= p->get_name()+" can go: ";
  for (uint x=0; x<GetMoves(p).size(); ++x)
  {
    AvailableMoves.push_back(GetMoves(p)[x]);
    if(AvailableMoves[x]==Left)
    {
      s+="LEFT ";
    }
    else if(AvailableMoves[x]==Right)
    {
      s+="RIGHT ";
    }
    else if(AvailableMoves[x]==Down)
    {
      s+="DOWN ";
    }
    else if(AvailableMoves[x]==Up)
    {
      s+="UP ";
    }
  }
  cout<< s<<endl;
}
    //print out available moves
  if (p->is_human()==true)
  {
    order = Command();
  }
  else
  {
    int BotDecider=rand()%3;
    if (BotDecider==0)
    {
      order="UP";
    }
    else if(BotDecider==1)
    {
      order="DOWN";
    }
    else if(BotDecider==2)
    {
      order ="LEFT";
    }
    else if(BotDecider==3)
    {
      order="RIGHT";
    }
  }
    if ((order=="UP")^(order=="DOWN")^(order=="LEFT")^(order=="RIGHT"))
    {
      ValidSpot = true;
    }
    else
    {
      goto startAgain;
    }
  //Translate Player Input into new position
  newSpot = Translate(order, p);
    if (ValidSpot==false)
    {
      goto startAgain;
    }
    if (MovePlayer(p,newSpot)==false)
    {
      goto startAgain;
    }
  SetSquareValue(p->get_position(),SquareType::Empty);
  p->SetPosition(newSpot);
  if(p->is_human()==true)
  {
    if(get_square_value(newSpot)==SquareType::Enemy||get_square_value(newSpot)==SquareType::Exit)
    {
      return;
    }
    if(get_square_value(newSpot)==SquareType::Treasure)
    {
      p->ChangePoints(100);
    }
    SetSquareValue(p->get_position(),SquareType::Human);
  }
  else
  {
    SetSquareValue(p->get_position(),SquareType::Enemy);
  }
}



//Translates a player or bot input into a movement
Position Board::Translate(string order, Player *p)
{
  Position pos=p->get_position();
  if(order=="UP")
  {
    pos.row=(pos.row)-1;
  }
  else if(order=="DOWN")
  {
      pos.row=(pos.row)+1;
  }
  else if(order=="LEFT")
  {
    pos.col=(pos.col)-1;
  }
  else if(order=="RIGHT")
  {
    pos.col=(pos.col)+1;
  }
  return pos;
}

//returns what the value of the exit square is
SquareType Board::GetExitOccupant()
{
  return (arr_[get_cols()-1][get_rows()-1]);
}

//gives bots a random starting location on an empty square
void Board::setBotStartingPos(Player* bot)
{
    repeat:
      int xrand = rand()%(get_cols()-1);
      int yrand=rand()%(get_rows()-1);
    if(arr_[xrand][yrand]!=SquareType::Empty)
    {
      goto repeat;
    }
    Position Pos;
    Pos.col=xrand;
    Pos.row=yrand;
    bot->SetPosition(Pos);
    SetSquareValue(Pos,(SquareType::Enemy));
}

//sets the needed values for Maze game
Maze::Maze()
{
  turn_count_=0;
  turn_marker_=-1;
}

//starts a new game AND plays it through to the end
void Maze::NewGame(Player *human, const int enemies)
{
  string human_name = human->get_name();
  Player HumanRemade(human_name,true);
  Player *Human_ref = &HumanRemade;
  players_.push_back(Human_ref);

  refresh:
  Board myBoard;
  if (myBoard.SledgeHammer()==false)
  {
    goto refresh;
  }
  board_ = &myBoard;
  for (int i=1; i<=enemies; i++)
  {
    Player* botref= new Player("bot",false);
    players_.push_back(botref);
    board_->setBotStartingPos(botref);
  }

  while(IsGameOver()==false)
  {

    TakeTurn(GetNextPlayer());
  }
  board_->drawBoard();


}
//Have the given player take their turn, and change turn count once player has gone
void Maze::TakeTurn(Player *p)
{
    board_->drawBoard();
    board_->Move(p);
    if(turn_marker_==0)
    {
      turn_count_++;
    }
}

//Checks if the player was either eaten or got out alive and outputs score and turns survived
bool Maze::IsGameOver()
{
  bool GameEnd = false;
  SquareType playerValue;
  Position playerPos;
  playerPos = players_[0]->get_position();
  playerValue=board_->get_square_value(playerPos);
  if (playerValue==SquareType::Enemy)
  {
    GameEnd=true;
    cout<<players_[0]->get_name()<<" has died with a score of: "<<players_[0]->get_points()<<endl;
    cout<<"You survived "<<turn_count_<<" turns";
  }
  else if(playerValue==SquareType::Exit)
  {
    GameEnd=true;
    cout<<players_[0]->get_name()<<" has won with a score of: "<<players_[0]->get_points()<<endl;
    cout<<"You survived "<<turn_count_<<" turns";
  }


  return GameEnd;
}

//Makes sure the board created has a clear exit
bool Board::SledgeHammer()
{
  int wallcount=0;
  for (int y=0; y<get_rows()-1; y++)
  {
    for (int x=0; x<get_cols()-1; x++)
    {
      if (arr_[x][y]==SquareType::Wall)
      {
        wallcount++;
      }
    }
  }
  if(arr_[1][0]==SquareType::Wall&&arr_[0][1]==SquareType::Wall)
  {
    return false;
  }
  if(arr_[get_cols()-1][get_rows()-2]==SquareType::Wall && arr_[get_cols()-2][get_rows()-1]==SquareType::Wall)
  {
    return false;
  }
  if (wallcount>(get_rows()-2)||wallcount>(get_cols()-2))
  {
    return false;
  }
  return true;
}

//goes through player_ vector and returns whichever play has the next turn
Player* Maze::GetNextPlayer()
{
  if (turn_marker_==players_.size()-1)
  {
    turn_marker_=-1;
  }
  turn_marker_++;
  return players_[turn_marker_];
}
