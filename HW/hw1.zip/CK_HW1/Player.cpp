#include <string>
#include <time.h>
#include <stdlib.h>
#include "Maze.h"
#include "Player.h"

using namespace std;

//constructor
Player::Player(const string name, const bool is_human)
{
    name_= name;
    is_human_=is_human;
    points_ = 0;
    pos_.col=0;
    pos_.row=0;
    //moveRange_=1; //was going to have bots changing the amount of turns the could get
}


Player::~Player()
{
    //dtor
}

//Change a players points --I made treasures worth 100
void Player::ChangePoints(const int x)
{
  points_=points_+x;
}

//sets a players position to a new position
void Player::SetPosition(Position pos)
{
  pos_.col = pos.col;
  pos_.row = pos.row;
}

//Returns score, I actually ended up not using this function, and did a lot of grabbing
//of values from players through inline Player functions that were run inside of the board or maze class
string Player::Stringify()
{
  string scoreBoard ="";
  scoreBoard = scoreBoard+name_ + " score: " + to_string(points_)+"\n";
  return scoreBoard;
}
