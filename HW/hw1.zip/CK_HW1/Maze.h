#ifndef _MAZE_H_
#define _MAZE_H_

#include <vector>
#include <string>
#include "Player.h"

using namespace std;

enum class SquareType { Wall, Exit, Empty, Human, Enemy, Treasure };


//returns a string with the name of the squaretype put into the function, very useful for debugging
/*std::string SquareTypeStringify(SquareType sq)
{
	if (sq==SquareType::Wall)
	{
		return "Wall";
	}
	else if(sq==SquareType::Exit)
	{
		return "Exit";
	}
	else if(sq==SquareType::Empty)
	{
		return "Empty";
	}
	else if(sq==SquareType::Human)
	{
		return "Human";
	}
	else if(sq==SquareType::Enemy)
	{
		return "Enemy";
	}
	else
	{
		return "Treasure";
	}
}*/

class Board {
public:

	Board();

	// already implemented in line
	int get_rows() const
	{
		return 4;
	}
	int get_cols() const
	{
		return 4;
	}
	//Go through the board's arr_[x][y] and set appropriate squaretype values
	//with all but first and last square being set randomly
	SquareType setRandSquare();

	//draw the state of the board
	void drawBoard();

	//get the Squaretype value of a position on the board
	SquareType get_square_value(Position pos) const;

	// set the value of a square to the given SquareType
	void SetSquareValue(Position pos, SquareType value);

	// get the possible Positions that a Player could move to
	// (not off the board or into a wall)
	vector<Position> GetMoves(Player *p);


	// An integral piece of my move statement, checks if the bot or player has inputed a valid option
	bool MovePlayer(Player *p, Position pos);

	//gets the command from human players and normalizes the string for comparisons
	string Command();

	//takes the normalized string from either the player or what the bot selected,
	//and applies changes to the board and player position
	Position Translate(string order, Player *p);

	//A function that wraps all the necesary pieces to move a player or bot into one concise statement
	void Move(Player *p);

	// Get the square type of the exit square
	SquareType GetExitOccupant();

	//Needed to give all created bots a random starting position on an empty tile
	void setBotStartingPos(Player*);

	//A function that runs through the map and makes sure that there definitely will be a solution
	bool SledgeHammer();


private:
	SquareType arr_[4][4];

};

class Maze
{
	public:

	Maze(); // constructor

	// initialize a new game, given one human player and
	// a number of enemies to generate
	void NewGame(Player *human, const int enemies);


	// have the given Player take their turn
	void TakeTurn(Player *p);

	// Get the next player in turn order
	Player* GetNextPlayer();

	// return true iff the human made it to the exit
	// or the enemies ate all the humans
	bool IsGameOver();

private:
Board *board_;
std::vector<Player *> players_;
int turn_count_;
uint turn_marker_;
};

#endif  // _MAZE_H_
