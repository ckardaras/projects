#include <iostream>
#include <vector>
#include <string>
#include <sstream>

#include "Society.h"

// Name(s): Chris Kardaras

using namespace std;


// Edit any of Society.h, Society.cpp and this file in your refactoring
// In addition to the refactoring tasks:
// When you are done, this program should be able to easily run for a different number
// of cities and you should be able to observe the growth in the cities for a given number of
// cycles of growth

int main() {
  Society s;
  int i=0;
  int pop, cycles;
  string name, input;




    // Prompt the user for the cities they would like to add
    // until they are done adding cities

    do{

      while(true)
      {
        cout<<"Enter Population: ";
        getline(cin, input);
        cout<<endl;
        stringstream mystream(input);
        if(mystream>>pop)
        {
          break;
        }
        cout<<"Please Enter a Number"<<endl;
      }
      cout<<"Enter City Name: ";
      getline(cin, name);
      cout<<endl;
      s.AddCity(i,pop,name);
      i++;
      cout<<"Enter 'end' to stop entering cities, enter 'c' to continue: ";
      getline(cin, input);
      cout<<endl;
  }while(input!="end");

    // Then ask the user how many times they would like to grow the cities

    while(true)
    {
      cout<<"How many cycles of growth do you want?: ";
      getline(cin, input);
      cout<<endl;
      stringstream mystream(input);
      if(mystream>>cycles)
      {
        break;
      }
      cout<<"Please Enter a Number"<<endl;
    }

    for(int i=0; i<cycles; i++)
    {
      cout << s << std::endl;
      s.GrowCities();
    }
}
