#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "catch.hpp"

#include "Rectangle.h"


//USED ABBREVIATIONS:
//TL = Top Left
//TR = Top Right
//BL = Bottom Left
//BR = Bottom Right

//Test Constructor
TEST_CASE ( "Constructor Test", "[rectangle]")
{
  Point TL;
  TL.x=-1;
  TL.y=1;
  Point TR;
  TR.x=1;
  TR.y=1;
  Point BL;
  BL.x=-1;
  BL.y=-1;
  Point BR;
  BR.x=1;
  BR.y=-1;
  SECTION("Top Left, Top Right")
  {
    Rectangle a(TR,TL);
    REQUIRE(a.get_p1().x==-1);
    REQUIRE(a.get_p1().y==1);
    REQUIRE(a.get_p2().x==1);
    REQUIRE(a.get_p2().y==1);
  }
  SECTION("Bottom Right, Bottom Left")
  {
    Rectangle b(BR,BL);
    REQUIRE(b.get_p1().x==-1);
    REQUIRE(b.get_p1().y==-1);
    REQUIRE(b.get_p2().x==1);
    REQUIRE(b.get_p2().y==-1);
  }
  SECTION("Top Left, Bottom Left")
  {
    Rectangle c(TL,BL);
    REQUIRE(c.get_p1().y==-1);
    REQUIRE(c.get_p1().x==-1);
    REQUIRE(c.get_p2().x==-1);
    REQUIRE(c.get_p2().y==1);
  }
  SECTION("Top Right, Bottom Right")
  {
    Rectangle d(TR,BR);
    REQUIRE(d.get_p1().x==1);
    REQUIRE(d.get_p1().y==-1);
    REQUIRE(d.get_p2().x==1);
    REQUIRE(d.get_p2().y==1);
  }
}

TEST_CASE ( "Get Width", "[rectangle]")
{
  Point TL;
  TL.x=-1;
  TL.y=1;
  Point TR;
  TR.x=1;
  TR.y=1;
  Point BL;
  BL.x=-1;
  BL.y=-1;
  Point BR;
  BR.x=1;
  BR.y=-1;
  SECTION("Top Right, Top Left")
  {
    Rectangle a(TR,TL);
    REQUIRE(a.GetWidth()==2);
  }
  SECTION("Bottom Right, Bottom Left")
  {
    Rectangle b(BR,BL);
    REQUIRE(b.GetWidth()==2);
  }
}

TEST_CASE ( "Get Height", "[rectangle]")
{
  Point TL;
  TL.x=-1;
  TL.y=1;
  Point TR;
  TR.x=1;
  TR.y=1;
  Point BL;
  BL.x=-1;
  BL.y=-1;
  Point BR;
  BR.x=1;
  BR.y=-1;
  SECTION("Top Right, Bottom Right")
  {
    Rectangle a(TR,BR);
    REQUIRE(a.GetHeight()==2);
  }
  SECTION("Top Left, Bottom Left")
  {
    Rectangle b(TL,BL);
    REQUIRE(b.GetHeight()==2);
  }
}

TEST_CASE ( "Calculate Area", "[rectangle]")
{
  Point TL;
  TL.x=-1;
  TL.y=1;
  Point BR;
  BR.x=1;
  BR.y=-1;
  SECTION("Top Left, Bottom Right")
  {
    Rectangle b(TL,BR);
    REQUIRE(b.CalculateArea()==4);
  }
}

TEST_CASE ( "Overlaps", "[rectangle]")
{
  Point TL;
  TL.x=-1;
  TL.y=1;
  Point BR;
  BR.x=1;
  BR.y=-1;
  SECTION("BR/TL == TL/BR")
  {
    Rectangle a(BR,TL);
    Rectangle b(BR,TL);
    REQUIRE(b.Overlaps(a)==true);
  }
}

TEST_CASE ( "Expand", "[rectangle]")
{
  Point TR;
  TR.x=1;
  TR.y=1;
  Point BL;
  BL.x=-1;
  BL.y=-1;
  SECTION("Top Right, Bottom Left")
  {
    Rectangle a(TR,BL);
    a.Expand();
    REQUIRE(a.get_p1().x==-2);
    REQUIRE(a.get_p1().y==-2);
    REQUIRE(a.get_p2().x==2);
    REQUIRE(a.get_p2().y==2);
  }
}

TEST_CASE ( "Shrink", "[rectangle]")
{
  Point TR;
  TR.x=1;
  TR.y=1;
  Point BL;
  BL.x=-1;
  BL.y=-1;
  SECTION("Top Right, Bottom Left")
  {
    Rectangle a(TR,BL);
    a.Shrink();
    REQUIRE(a.get_p1().x==0);
    REQUIRE(a.get_p1().y==0);
    REQUIRE(a.get_p2().x==0);
    REQUIRE(a.get_p2().y==0);
  }
}
