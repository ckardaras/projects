#include "Rectangle.h"
#include <cmath>

using namespace std;
//Name: Chris Kardaras
//Found bugs that resulted from flipping top right and top left place
//Found Bugs that resulted when you gave top right and lower left corner of Rectangle
//getwidth, could give a negative number when points were put in wrong order
//getheight, could give a negative number when points were put in wrong order
//Overlapping could give a false if point1==Other.point2 and vice-versa
//If points were put in wrong order in consturct both shrink and expand changed the points the wrong way



// p1 is the lower left corner
// p2 is the upper right corner
Rectangle::Rectangle(Point p1, Point p2)
{
  if(p1.x<=p2.x)  //given x1<=x2
  {
    if(p1.y<=p2.y)  //if y is also less or equal
    {
      p1_=p1;     //BR TR
      p2_=p2;
    }
    else        //given TL BR
    {
      int temp = p1.x; //hold onto original p1.x
      p1.x=p2.x;//TL -> TR = take BR'x
      //p1 holds TR
      p2_=p1;

      p1.x=temp;
      p1.y=p2.y;
      p1_=p1;//BR -> TR = take TL's Y
    }
  }
  else if(p1.x>p2.x)
  {
    if(p1.y>=p2.y)
    {
      p2_=p1;
      p1_=p2;
    }
    else
    {
      p2_=p2;
      p1_=p1;
    }
  }
}

// get the width of the rectangle
// between p1.x and p2.x
int Rectangle::GetWidth()
{
  if ((p1_.x<0)&&(p2_.x>0))
  {
    return abs(p1_.x)+p2_.x;
  }
  else
  {
    return abs(p2_.x-p1_.x);
  }
}
// get the height of the rectangle
// between p2.y and p2.y
int Rectangle::GetHeight()
{
  if ((p1_.y<0)&&(p2_.y>0))
  {
    return abs(p1_.y)+p2_.y;
  }
  else
  {
    return abs(p2_.y-p1_.y);
  }
}

// returns true iff this rectangle shares any points with the other one
bool Rectangle::Overlaps(Rectangle& other)
{
  if(((p1_.x==other.get_p1().x)&&(p1_.y==other.get_p1().y))
    ||((p2_.x==other.get_p1().x)&&(p2_.y==other.get_p1().y))
    ||((p1_.x==other.get_p2().x)&&(p1_.y==other.get_p2().y))
    ||((p2_.x==other.get_p2().x)&&(p2_.y==other.get_p2().y)))
    {
      return true;
    }
  else
  {
    return false;
  }

}

// returns the area of this rectangle
int Rectangle::CalculateArea()
{
  return (GetHeight()*GetWidth());
}

// moves the bottom left coordinate down one and to the left one
// moves the upper right coordinate up one and to the right one
void Rectangle::Expand()
{
  p1_.x=(get_p1().x)-1;
  p1_.y=(get_p1().y)-1;
  p2_.x=(get_p2().x)+1;
  p2_.y=(get_p2().y)+1;
}

// moves the bottom left coordinate up one and to the right one
// moves the upper right coordinate down one and to the left one
void Rectangle::Shrink()
{
  p1_.x=(get_p1().x)+1;
  p1_.y=(get_p1().y)+1;
  p2_.x=(get_p2().x)-1;
  p2_.y=(get_p2().y)-1;

}
